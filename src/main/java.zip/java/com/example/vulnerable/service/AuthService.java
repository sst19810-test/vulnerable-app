package com.example.vulnerable.service;

import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.util.Random;

@Service
public class AuthService {

    // VULNERABILITY: Hardcoded credentials
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "P@ssw0rd123";
    private static final String SECRET_KEY = "mySecretKey12345";  // VULNERABILITY: Hardcoded secret
    private static final String API_KEY = "sk-1234567890abcdef";  // VULNERABILITY: Hardcoded API key

    // VULNERABILITY: Weak password hashing (MD5)
    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(Integer.toHexString(0xFF & b));
            }
            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();  // VULNERABILITY: Stack trace exposure
            return null;
        }
    }

    // VULNERABILITY: Weak random number generation
    public String generateToken() {
        Random random = new Random();  // Should use SecureRandom
        return String.valueOf(random.nextInt(999999));
    }

    // VULNERABILITY: Timing attack vulnerability
    public boolean authenticate(String username, String password) {
        String storedPassword = getStoredPassword(username);
        if (storedPassword == null) {
            return false;
        }
        // Vulnerable to timing attacks
        return storedPassword.equals(password);
    }

    private String getStoredPassword(String username) {
        if (ADMIN_USERNAME.equals(username)) {
            return ADMIN_PASSWORD;
        }
        return null;
    }

    // VULNERABILITY: Insecure SSL/TLS configuration (commented code)
    /*
    public void disableSSLVerification() {
        TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }
        };
    }
    */
}
