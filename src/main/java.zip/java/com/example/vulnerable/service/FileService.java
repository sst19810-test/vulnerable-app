package com.example.vulnerable.service;

import com.example.vulnerable.util.XmlParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class FileService {

    @Autowired
    private XmlParser xmlParser;

    // VULNERABILITY: Path Traversal
    public String readFile(String filename) throws IOException {
        File file = new File("/tmp/" + filename);  // No path validation
        BufferedReader reader = new BufferedReader(new FileReader(file));
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line).append("\n");
        }
        reader.close();
        return content.toString();
    }

    // VULNERABILITY: Arbitrary file write
    public String writeFile(String filename, String content) {
        try {
            // VULNERABILITY: No validation of filename or path
            FileWriter writer = new FileWriter("/tmp/" + filename);
            writer.write(content);
            writer.close();
            return "File written successfully";
        } catch (IOException e) {
            return "Error: " + e.getMessage();  // VULNERABILITY: Error message disclosure
        }
    }

    // VULNERABILITY: Command Injection
    public String executeCommand(String cmd) throws IOException {
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec(cmd);  // Directly executing user input

        BufferedReader reader = new BufferedReader(
            new InputStreamReader(process.getInputStream())
        );

        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }
        return output.toString();
    }

    // VULNERABILITY: XXE
    public String parseXml(String xmlContent) {
        return xmlParser.parse(xmlContent);
    }

    // VULNERABILITY: Zip Slip
    public void unzip(String zipFilePath, String destDirectory) throws IOException {
        java.util.zip.ZipInputStream zis = new java.util.zip.ZipInputStream(
            new FileInputStream(zipFilePath)
        );

        java.util.zip.ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            // VULNERABILITY: No validation of zip entry path
            File newFile = new File(destDirectory + File.separator + zipEntry.getName());
            new File(newFile.getParent()).mkdirs();
            FileOutputStream fos = new FileOutputStream(newFile);

            byte[] buffer = new byte[1024];
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }
}
